# KeyControl3.py

from raspisim import *

robot = Robot()
gear = Gear()
speed = 15

while not robot.isEscapeHit():
    if robot.isUpHit():
        speed += 5
        print "speed =", speed
        gear.setSpeed(speed)
        gear.forward()
    elif robot.isDownHit():
        speed += - 5
        print "speed =", speed
        gear.setSpeed(speed)
        gear.forward()
    elif robot.isLeftHit():
        gear.leftArc(0.1)
    elif robot.isRightHit():
        gear.rightArc(0.1)
    elif robot.isEnterHit():
        gear.stop()    
robot.exit()

