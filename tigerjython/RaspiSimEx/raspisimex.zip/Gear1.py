# Gear1.py

from raspisim import *

robot = Robot()
gear = Gear()
gear.forward(2000)
robot.exit()

