# KeyControl1.py

from raspisim import *

robot = Robot()
gear = Gear()
gear.setSpeed(20)

while not robot.isEscapeHit():
    if robot.isUpHit():
        gear.forward()
    elif robot.isDownHit():
        gear.backward()
    elif robot.isLeftHit():
        gear.leftArc(0.1)
    elif robot.isRightHit():
        gear.rightArc(0.1)
    elif robot.isEnterHit():
        gear.stop()    
robot.exit()

